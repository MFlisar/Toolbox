package com.michaelflisar.toolbox.tasks.plan

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import com.michaelflisar.toolbox.extensions.isDark
import com.michaelflisar.toolbox.tasks.TaskConfig

@Composable
fun rememberTaskMessageColors(
    colorSuccessOnDark: Color = Color(0xFF81C784), // Green 300
    colorSuccessOnLight: Color = Color(0xFF388E3C), // Green 700
    colorWarningOnDark: Color = Color(0xFFFFB74D), // Orange 300
    colorWarningOnLight: Color = Color(0xFFF57C00), // Orange 700
    colorErrorOnDark: Color = Color(0xFFE57373), // Red 300
    colorErrorOnLight: Color = Color(0xFFD32F2F), // Red 700
    colorInfoOnDark: Color = Color(0xFF64B5F6), // Blue 300
    colorInfoOnLight: Color = Color(0xFF1976D2) // Blue 700
): TaskMessageColors {
    val isBackgroundDark = MaterialTheme.colorScheme.background.isDark()
    return remember(
        isBackgroundDark,
        colorSuccessOnDark,
        colorSuccessOnLight,
        colorWarningOnDark,
        colorWarningOnLight,
        colorErrorOnDark,
        colorErrorOnLight,
        colorInfoOnDark,
        colorInfoOnLight
    ) {
        TaskMessageColors(
            isBackgroundDark = isBackgroundDark,
            colorSuccessOnDark = colorSuccessOnDark,
            colorSuccessOnLight = colorSuccessOnLight,
            colorWarningOnDark = colorWarningOnDark,
            colorWarningOnLight = colorWarningOnLight,
            colorErrorOnDark = colorErrorOnDark,
            colorErrorOnLight = colorErrorOnLight,
            colorInfoOnDark = colorInfoOnDark,
            colorInfoOnLight = colorInfoOnLight
        )
    }
}

@Stable
data class TaskMessageColors(
    val isBackgroundDark: Boolean,
    private val colorSuccessOnDark: Color,
    private val colorSuccessOnLight: Color,
    private val colorWarningOnDark: Color,
    private val colorWarningOnLight: Color,
    private val colorErrorOnDark: Color,
    private val colorErrorOnLight: Color,
    private val colorInfoOnDark: Color,
    private val colorInfoOnLight: Color
) {
    fun colorSuccess() = if (isBackgroundDark) colorSuccessOnDark else colorSuccessOnLight
    fun colorWarning() = if (isBackgroundDark) colorWarningOnDark else colorWarningOnLight
    fun colorError() = if (isBackgroundDark) colorErrorOnDark else colorErrorOnLight
    fun colorInfo() = if (isBackgroundDark) colorInfoOnDark else colorInfoOnLight
    fun colorSuccess(background: Color) = if (background.isDark()) colorSuccessOnDark else colorSuccessOnLight
    fun colorWarning(background: Color) = if (background.isDark()) colorWarningOnDark else colorWarningOnLight
    fun colorError(background: Color) = if (background.isDark()) colorErrorOnDark else colorErrorOnLight
    fun colorInfo(background: Color) = if (background.isDark()) colorInfoOnDark else colorInfoOnLight
}

sealed interface TaskMessage {

    data class Text(
        val text: String,
        val type: TaskMessageType = TaskMessageType.Info,
    ) : TaskMessage {

        @Composable
        fun annotated(
            config: TaskConfig.ViewerConfig,
            background: Color
        ): AnnotatedString {
            return buildAnnotatedString {

                val prefix = when (type) {
                    TaskMessageType.Warning -> config.prefixWarning
                    TaskMessageType.Error -> config.prefixError
                    TaskMessageType.Info -> ""
                }

                if (prefix.isEmpty()) {
                    append(text)
                    return@buildAnnotatedString
                }

                text.lines().forEachIndexed { index, line ->

                    if (index > 0) {
                        append('\n')
                    }

                    when (type) {
                        TaskMessageType.Warning -> {
                            withStyle(
                                SpanStyle(color = if (index == 0) config.taskMessageColors.colorWarning(background) else Color.Transparent)
                            ) {
                                append(config.prefixWarning)
                            }
                        }

                        TaskMessageType.Error -> {
                            withStyle(
                                SpanStyle(color = if (index == 0) config.taskMessageColors.colorError(background) else Color.Transparent)
                            ) {
                                append(config.prefixError)
                            }
                        }

                        TaskMessageType.Info -> Unit
                    }
                    append(line)
                }
            }
        }
    }

    data class Rich(
        val text: AnnotatedString,
    ) : TaskMessage

    data class ItemList(
        val items: List<String>,
        val title: String? = null,
        val type: TaskMessageType = TaskMessageType.Info,
    ) : TaskMessage
}


enum class TaskMessageType {
    Info,
    Warning,
    Error
}