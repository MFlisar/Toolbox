package com.michaelflisar.toolbox.feature.infos

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import com.michaelflisar.toolbox.components.MyColumn
import com.michaelflisar.toolbox.theme.spacing
import com.michaelflisar.toolbox.ui.MyScrollableLazyColumn

internal sealed class Info {

    interface InfoText {
        val text: String
        val subText: String
        val color: Color
    }

    class Title(
        override val text: String,
        override val subText: String = "",
        override val color: Color = Color.Unspecified,
    ) : Info(), InfoText

    class Text(
        override val text: String,
        override val subText: String = "",
        override val color: Color = Color.Unspecified,
    ) : Info(), InfoText

    data object InsetPlus : Info()
    data object InsetMinus : Info()
}

class InfoState internal constructor(
    internal val infos: SnapshotStateList<Info>,
) {
    fun size() = infos.size

    fun addTitle(
        text: String,
        subText: String = "",
        color: Color = Color.Unspecified,
    ) {
        infos.add(Info.Title(text, subText, color))
    }

    fun addText(
        text: String,
        subText: String = "",
        color: Color = Color.Unspecified,
    ) {
        infos.add(Info.Text(text, subText, color))
    }

    fun insetIncrease() {
        infos.add(Info.InsetPlus)
    }

    fun insetDecrease() {
        infos.add(Info.InsetMinus)
    }

    internal fun list() = infos.toList()

    companion object {
        fun create() = InfoState(mutableStateListOf())
    }
}

@Composable
fun rememberInfos() = InfoState(
    remember { mutableStateListOf() }
)

@Composable
fun Infos(
    modifier: Modifier = Modifier,
    autoScroll: MutableState<Boolean> = remember { mutableStateOf(true) },
    infos: InfoState,
    inset: Dp = MaterialTheme.spacing.small,
) {
    val listState = rememberLazyListState()
    LaunchedEffect(infos.size(), autoScroll.value) {
        if (infos.size() > 0 && autoScroll.value)
            listState.scrollToItem(infos.size() - 1)
    }
    val items = remember(infos.size()) { infos.list() }
    Column(modifier = modifier) {
        MyScrollableLazyColumn(
            Modifier.fillMaxWidth().weight(1f),
            MaterialTheme.spacing.mini,
            state = listState
        ) {
            if (items.isEmpty()) {
                item(-1) {
                    Text(text = "Empty!", style = MaterialTheme.typography.bodyMedium)
                }
            } else {
                items.forEachIndexed { index, info ->
                    when (info) {
                        Info.InsetMinus,
                        Info.InsetPlus,
                            -> {
                        }

                        is Info.Text -> item(index) { InfoText(info, items.take(index), inset) }
                        is Info.Title -> item(index) { TitleLine(info, items.take(index), inset) }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoText(
    info: Info.Text,
    infosAbove: List<Info>,
    inset: Dp,
) {
    val style = MaterialTheme.typography.bodyMedium
    Line(info.text, info.subText, style, info.color, infosAbove, inset)
}

@Composable
private fun TitleLine(
    info: Info.Title,
    infosAbove: List<Info>,
    inset: Dp,
) {
    val style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
    Line(info.text, info.subText, style, info.color, infosAbove, inset)
}

@Composable
private fun Line(
    text: String,
    subText: String,
    style: TextStyle,
    color: Color,
    infosAbove: List<Info>,
    inset: Dp,
) {
    val countPlus = infosAbove.count { it is Info.InsetPlus }
    val countMinus = infosAbove.count { it is Info.InsetMinus }
    val insetFactor = countPlus - countMinus
    MyColumn(
        modifier = Modifier.padding(start = inset * insetFactor)
    ) {
        Text(
            text = text,
            style = style,
            color = color
        )
        if (subText.isNotEmpty()) {
            Text(
                text = subText,
                style = style,
                color = color
            )
        }
    }
}