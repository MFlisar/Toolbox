package com.michaelflisar.toolbox.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyInputButton(
    modifier: Modifier = Modifier,
    title: String = "",
    value: String,
    minLines: Int = 1,
    maxLines: Int = 1,
    minWidth: Dp = ButtonDefaults.MinWidth,
    enabled: Boolean = true,
    placeholder: @Composable (() -> Unit)? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    colors: TextFieldColors = OutlinedTextFieldDefaults.colors(),
    onClick: () -> Unit,
) {
    MyOutlinedDecoratedContainer(
        title = title,
        modifier = modifier.width(IntrinsicSize.Min),
        enabled = enabled,
        placeholder = placeholder,
        leadingIcon = leadingIcon,
        colors = colors,
        minWidth = minWidth,
        onClick = onClick
    ) {
        Text(
            modifier = Modifier
                .fillMaxWidth()
                .then(MyOutlinedDecoratedContainer.MODIFIER_CORRECTION),
            text = value,
            style = LocalTextStyle.current,
            color = MaterialTheme.colorScheme.onSurface,
            minLines = minLines,
            maxLines = maxLines
        )
    }
}