package com.michaelflisar.toolbox.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.michaelflisar.toolbox.spacing


object MyDropdownButton {

    sealed class Type {

        internal abstract fun onClick()

        class Dropdown internal constructor(
            val expanded: MutableState<Boolean>,
            val items: List<Entry>,
        ) : Type() {
            override fun onClick() {
                expanded.value = !expanded.value
            }

            @Composable
            internal fun Popup() {
                DropdownMenu(
                    expanded = expanded.value,
                    onDismissRequest = {
                        expanded.value = false
                    }
                ) {
                    items.forEach { item ->
                        when (item) {
                            is Entry.Button -> {
                                DropdownMenuItem(
                                    onClick = {
                                        item.onClick()
                                        if (item.dismissOnClick) {
                                            expanded.value = false
                                        }
                                    },
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(
                                                MaterialTheme.spacing.small
                                            )
                                        ) {
                                            item.icon?.let {
                                                Icon(
                                                    it,
                                                    null,
                                                    tint = item.foregroundColor
                                                        ?: LocalContentColor.current//.copy(alpha = LocalContentAlpha.current)
                                                )
                                            }
                                            Text(
                                                item.text,
                                                color = item.foregroundColor ?: Color.Unspecified
                                            )
                                        }
                                    }
                                )
                            }

                            Entry.Divider -> {
                                VerticalDivider()
                            }
                        }
                    }
                }
            }
        }

        class Click internal constructor(
            val onClick: () -> Unit,
        ) : Type() {
            override fun onClick() {
                this.onClick.invoke()
            }
        }
    }

    sealed class Entry {

        class Button(
            val text: String,
            val icon: ImageVector? = null,
            val foregroundColor: Color? = null,
            val dismissOnClick: Boolean = true,
            val onClick: () -> Unit,
        ) : Entry()

        data object Divider : Entry()

    }

}

private object MyDropdownButtonDefaults {

    @Composable
    fun typeDropdown(
        items: List<MyDropdownButton.Entry>,
        expanded: MutableState<Boolean> = remember { mutableStateOf(false) },
    ): MyDropdownButton.Type {
        return MyDropdownButton.Type.Dropdown(expanded, items)
    }

    @Composable
    fun typeClick(
        onClick: () -> Unit,
    ): MyDropdownButton.Type {
        return MyDropdownButton.Type.Click(onClick)
    }
}

// -------------------------
// public API
// -------------------------

@Composable
fun MyDropdownButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    // button style
    shape: Shape = ButtonDefaults.shape,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    elevation: ButtonElevation? = ButtonDefaults.buttonElevation(),
    border: BorderStroke? = null,
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    // content
    content: @Composable RowScope.() -> Unit,
) {
    MyDropdownButton(
        type = MyDropdownButtonDefaults.typeClick(onClick),
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        style = MyButtonDefaults.styleDefault(shape, colors, elevation, border, contentPadding),
        content = content
    )
}

@Composable
fun MyDropdownButton(
    items: List<MyDropdownButton.Entry>,
    expanded: MutableState<Boolean> = remember { mutableStateOf(false) },
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    // button style
    shape: Shape = ButtonDefaults.shape,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    elevation: ButtonElevation? = ButtonDefaults.buttonElevation(),
    border: BorderStroke? = null,
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    // content
    content: @Composable RowScope.() -> Unit,
) {
    MyDropdownButton(
        type = MyDropdownButtonDefaults.typeDropdown(items, expanded),
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        style = MyButtonDefaults.styleDefault(shape, colors, elevation, border, contentPadding),
        content = content
    )
}

@Composable
fun MyDropdownOutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    // button style
    shape: Shape = ButtonDefaults.outlinedShape,
    colors: ButtonColors = ButtonDefaults.outlinedButtonColors(),
    elevation: ButtonElevation? = null,
    border: BorderStroke? = ButtonDefaults.outlinedButtonBorder(enabled = enabled),
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    // content
    content: @Composable RowScope.() -> Unit,
) {
    MyDropdownButton(
        type = MyDropdownButtonDefaults.typeClick(onClick),
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        style = MyButtonDefaults.styleOutlined(shape, colors, elevation, border, contentPadding),
        content = content
    )
}

@Composable
fun MyDropdownOutlinedButton(
    items: List<MyDropdownButton.Entry>,
    expanded: MutableState<Boolean> = remember { mutableStateOf(false) },
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    // button style
    shape: Shape = ButtonDefaults.outlinedShape,
    colors: ButtonColors = ButtonDefaults.outlinedButtonColors(),
    elevation: ButtonElevation? = null,
    border: BorderStroke? = ButtonDefaults.outlinedButtonBorder(enabled = enabled),
    contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
    // content
    content: @Composable RowScope.() -> Unit,
) {
    MyDropdownButton(
        type = MyDropdownButtonDefaults.typeDropdown(items, expanded),
        modifier = modifier,
        enabled = enabled,
        interactionSource = interactionSource,
        style = MyButtonDefaults.styleOutlined(shape, colors, elevation, border, contentPadding),
        content = content
    )
}

// -------------------------
// internal API
// -------------------------

@Composable
private fun MyDropdownButton(
    type: MyDropdownButton.Type,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource? = null,
    // button style
    style: MyButton.Style,
    // content
    content: @Composable RowScope.() -> Unit,
) {
    ButtonWrapper(
        type = type,
        button = {
            MyButton(
                onClick = type::onClick,
                style = style,
                modifier = modifier,
                enabled = enabled,
                interactionSource = interactionSource
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    content()
                    EndIcon(type)
                }
            }
        }
    )
}

@Composable
private fun EndIcon(
    type: MyDropdownButton.Type,
) {
    val rotation: Float = when (type) {
        is MyDropdownButton.Type.Click -> 0f
        is MyDropdownButton.Type.Dropdown -> animateFloatAsState(if (type.expanded.value) 180f else 0f).value
    }
    Icon(
        modifier = Modifier.rotate(rotation),
        imageVector = Icons.Default.ArrowDropDown,
        contentDescription = null
    )
}

@Composable
private fun ButtonWrapper(
    type: MyDropdownButton.Type,
    button: @Composable () -> Unit,
) {
    Box {
        button()
        when (type) {
            is MyDropdownButton.Type.Click -> {
                // -
            }

            is MyDropdownButton.Type.Dropdown -> type.Popup()
        }
    }
}