package com.michaelflisar.toolbox.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.ui.graphics.painter.Painter
import com.michaelflisar.composechangelog.Changelog
import com.michaelflisar.composedebugdrawer.core.DebugDrawerState
import com.michaelflisar.composethemer.ComposeTheme
import com.michaelflisar.composethemer.themes.DefaultThemes
import com.michaelflisar.lumberjack.core.interfaces.IFileLoggingSetup
import com.michaelflisar.toolbox.app.classes.Developer
import com.michaelflisar.toolbox.app.debug.DebugPrefs
import com.michaelflisar.toolbox.app.features.logging.ConsoleLoggingSetup
import com.michaelflisar.toolbox.app.features.preferences.BasePrefs

class AppSetup(
    val developer: Developer = Developer.Author(
        Constants.DEVELOPER_NAME,
        Constants.DEVELOPER_EMAIL
    ),
    val appData: AppData,
    val icon: @Composable () -> Painter,
    val themeSupport: ThemeSupport,
    val prefs: BasePrefs,
    val debugPrefs: DebugPrefs,
    val debugDrawer: (@Composable (drawerState: DebugDrawerState) -> Unit)?,
    val privacyPolicyLink: String,
    val disableLanguagePicker: Boolean,
    val fileLoggingSetup: IFileLoggingSetup?,
    val consoleLoggingSetup: ConsoleLoggingSetup?,
    val changelogSetup: Changelog.Setup?,
    val isDebugBuild: Boolean,
) {
    companion object {
        fun get() = App.requireSingleton<AppSetup>()
    }

    class ThemeSupport(
        val themes: List<ComposeTheme.Theme> = DefaultThemes.getAllThemes(),
        val supportThemeSelector: Boolean,
        val supportDarkLight: Boolean,
        val supportContrast: Boolean,
        val supportDynamicColors: Boolean,
        val supportToolbarStyles: Boolean,
    ) {
        companion object {
            fun disabled(
                themes: List<ComposeTheme.Theme> = DefaultThemes.getAllThemes(),
            ) = ThemeSupport(themes, false, false, false, false, false)

            fun full(
                themes: List<ComposeTheme.Theme> = DefaultThemes.getAllThemes(),
            ) = ThemeSupport(themes, true, true, true, true, true)
        }

        fun supportsCustomThemes() = ComposeTheme.getRegisteredThemes().size > 1

        fun supportsTheming() =
            ComposeTheme.getRegisteredThemes().size > 1 || supportDarkLight || supportContrast || supportDynamicColors
    }

    @Stable
    class AppData(
        val versionCode: Int,
        val versionName: String,
        val namespace: String,
        val name: String,
    )

}