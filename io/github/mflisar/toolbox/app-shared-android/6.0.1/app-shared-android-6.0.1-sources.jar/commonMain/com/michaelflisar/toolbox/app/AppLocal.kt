package com.michaelflisar.toolbox.app

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.ExperimentalComposeUiApi
import com.michaelflisar.toolbox.app.features.activity.Activity
import com.michaelflisar.toolbox.app.features.activity.LocalActivity
import com.michaelflisar.toolbox.app.features.backhandlerregistry.LocalBackHandlerRegistry
import com.michaelflisar.toolbox.app.features.backhandlerregistry.rememberBackHandlerRegistry

/**
 * stellt app spezifische Locals zur Verfügung welche global und überall verfügbar sein sollen
 * bereits außerhalb von root!
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun ProvideAppLocals(
    activity: Activity,
    content: @Composable () -> Unit,
) {
    val backHandlerRegistry = rememberBackHandlerRegistry()
    CompositionLocalProvider(
        LocalBackHandlerRegistry provides backHandlerRegistry,
        LocalActivity provides activity,
    ) {
        // Level 1: Selection Toolbar
        // Level 2: später registriert sich ggf. auch der Debug Drawer
        // Level 3: Settings Page registriert die eigene logik auch darin
        //val selectionToolbarState = LocalSelectionToolbarState.current
        //RegisterBackHandler(
        //    canHandle = {
        //        val handle = selectionToolbarState.isInSelectionMode
        //        println("SelectionToolbarState: canHandleBackPress = $handle")
        //        handle
        //    },
        //    handle = {
        //        L.logIf(ToolboxLogging.Tag.Navigation)
        //            ?.i { "BackHandlerRegistry - SelectionToolbarState handles back press" }
        //        selectionToolbarState.clearSelection(finish = true)
        //    }
        //)

        content()
    }
}