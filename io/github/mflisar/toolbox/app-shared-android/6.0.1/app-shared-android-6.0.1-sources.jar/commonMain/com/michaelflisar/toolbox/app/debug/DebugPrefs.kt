package com.michaelflisar.toolbox.app.debug

import com.michaelflisar.kotpreferences.core.SettingsModel
import com.michaelflisar.kotpreferences.core.interfaces.Storage
import com.michaelflisar.toolbox.app.AppSetup

class DebugPrefs(storage: Storage) : SettingsModel(storage) {

    companion object {
        fun get() = AppSetup.get().debugPrefs
    }

    val showDeveloperSettings by boolPref(false)
    val forceIsProInDebug by boolPref(false)
    val showDebugDrawer by boolPref(false)

    // DebugDrawer
    val debugDrawerExpandedIds by stringSetPref(emptySet())
    val showRegionInformations by boolPref(true)
    val showRegionDevice by boolPref(true)
    val showRegionThemes by boolPref(true)
    val showRegionLogging by boolPref(true)
    val showRegionData by boolPref(true)
}